#' Title
#'
#' @param final_output
#'
#' @return
#' @export
#'
#' @examples
getCOMIDsWithinThreshold <- function(final_output) {
  return(final_output$COMID)
}
